# LINE Sticker Ideator

自分の **LINE トーク履歴** を解析して、

1. **本当に使うであろうスタンプ文言** を頻度ベースで抽出し、
2. **画像生成 AI に渡せるデザインブリーフ** (palette / mood / prompt) を自動生成し、
3. **LINE スタンプ規格 (370×320 PNG / 透過)** に沿ったラフモックアップ + ZIP 一括エクスポート

までをワンストップで行う、デザイン補助ツールです。最終ブラッシュアップは Midjourney / SDXL / DALL-E などの画像生成 AI、または手描きで仕上げる前提の **叩き台ジェネレータ** です。

## 設計方針

- **プライバシー最優先**: チャット履歴はすべてブラウザ内で処理。サーバ送信なし。
- **形態素解析なし**: kuromoji 等を入れず、短文丸ごと頻度 + 文字 n-gram + 絵文字でシグナルを取る。バンドル軽量・依存少。
- **AI への引き継ぎ前提**: 出力は (a) PNG ラフ、(b) Markdown ブリーフ、(c) JSON プロンプト の三系統。

## 使い方

```bash
cd line-sticker
npm install
npm run dev   # http://localhost:5174
```

1. LINE アプリ → トーク → 設定 → トーク履歴を送信 → **テキスト形式** で `.txt` を取得
2. ブラウザにドラッグ&ドロップ
3. 「自分」のスクリーン名でフィルタ → 分析
4. ラフが並んだら ZIP / Markdown / JSON のいずれかで書き出し

サンプル履歴で動作確認したい場合は「サンプル履歴を試す」ボタンから。

## スコアリングの仕組み

| シグナル | 内容 | スコア重み |
|---|---|---|
| **whole-message** | 14 文字以下の単発返信丸ごと | 高 (短いほどボーナス) |
| **n-gram (2〜6)** | 共起しやすい文字列 | 中 (`whole` の部分文字列なら抑制) |
| **emoji** | 絵文字単体 | 低 |

各候補は感情辞書で `joy / love / surprise / sad / question / chill / hype / thanks / neutral` に分類され、感情ごとにパレットが固定 → パック全体でトーンが揃います。

## 出力サンプル

### Markdown ブリーフ抜粋

```markdown
### 03. 「ありがとう」

- Emotion: **thanks**
- Palette: fill `#FFB347` / stroke `#3B1F00` / accent `#FFFFFF`
- Mood: grateful, warm, slight-bow gesture

**Image prompt**

LINE-style sticker, daily-use Japanese reactions pack, transparent background PNG, 370x320px, grateful, warm, slight-bow gesture, palette #FFB347/#3B1F00/#FFFFFF, a small expressive cartoon mascot ... holding or framing the bold Japanese text "ありがとう" ...
```

### JSON プロンプト (画像生成 AI バッチ投入用)

```json
{
  "stickers": [
    {
      "index": 1,
      "filename": "01.png",
      "text": "おはよ",
      "emotion": "chill",
      "palette": { "fill": "#5DD6B9", "stroke": "#0E2A26", "accent": "#A8E8DA", "mood": "calm, casual, easygoing" },
      "prompt": "LINE-style sticker, ...",
      "negative_prompt": "photorealistic, ...",
      "width": 370,
      "height": 320
    }
  ]
}
```

## ファイル構成

```
line-sticker/
├── index.html
├── src/
│   ├── main.ts          # UI bootstrap
│   ├── style.css
│   ├── parser.ts        # LINE .txt パーサ (JP/EN 両対応)
│   ├── analyzer.ts      # 頻度+n-gram+絵文字解析
│   ├── designBrief.ts   # 感情→パレット→AIプロンプト生成
│   ├── canvasRender.ts  # 370×320 透過 PNG ラフ描画
│   └── lineSpec.ts      # LINE Creators Market 規格定数
└── public/
    └── samples/sample-chat.txt
```

## 注意事項

- LINE Creators Market の **審査基準** (実在人物の肖像、商標、公序良俗等) はツール側で検査しません。提出前に必ず公式ガイドラインを確認してください。
- ラフモックアップは座標・サイズの当たり付け用です。提出用の最終 PNG は画像生成 AI または手描きで作り直してください。
- 著作権: 入力した履歴の **送信者全員に対する許諾** を得てください。
