import type { StickerBrief } from "./designBrief";
import type { Emotion } from "./analyzer";
import { STICKER_W, STICKER_H, SAFE_MARGIN } from "./lineSpec";

// --- Style constants (locked palette inspired by the 墨絵+顔+blush+葉 concept ref) ---
const INK = "#0E0E10";          // sumi black
const BLUSH = "#F4A6A6";        // pink cheek
const LEAF_A = "#7BB661";        // matcha green
const LEAF_B = "#5C9A4D";
const W_TEXT = "#1B1B1F";        // www handwritten

const BRUSH_FONT = '"Yuji Boku", "Yuji Mai", "Hiragino Mincho ProN", "Yu Mincho", serif';
const W_FONT = '"Yuji Mai", "Yuji Boku", "Comic Sans MS", system-ui, sans-serif';

// Font weight: Yuji Boku ships at 400 (it's already heavy/brush). Using 900
// makes browsers synthesize a fake bold which destroys the brush look.
const BRUSH_WEIGHT = 400;

// Make Canvas drawing reproducible: a tiny seedable PRNG.
function mulberry32(seed: number) {
  let t = seed >>> 0;
  return () => {
    t = (t + 0x6d2b79f5) >>> 0;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r = (r + Math.imul(r ^ (r >>> 7), 61 | r)) ^ r;
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function seedFromText(s: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

// Wait for embedded brush font to be available before rendering.
let fontsReady: Promise<void> | null = null;

export function ensureFonts(probeText = "草おはようありがとう"): Promise<void> {
  if (!fontsReady) {
    fontsReady = (async () => {
      if (typeof document === "undefined" || !document.fonts) return;
      try {
        // Trigger load for the specific glyphs we'll render — Yuji Boku is split
        // into many unicode-range subsets, so loading "120px font" without text
        // doesn't actually fetch the JP subsets.
        await document.fonts.load(`400 120px "Yuji Boku"`, probeText);
        await document.fonts.load(`400 36px "Yuji Mai"`, "www");
        await document.fonts.ready;
      } catch {
        /* fall back to system serif */
      }
    })();
  }
  return fontsReady;
}

// Force reload of glyphs for a freshly entered phrase (subset fetch is on demand).
export async function preloadGlyphs(text: string): Promise<void> {
  if (typeof document === "undefined" || !document.fonts) return;
  try {
    await document.fonts.load(`400 120px "Yuji Boku"`, text);
    await document.fonts.ready;
  } catch {
    /* ignore */
  }
}

export function renderSticker(brief: StickerBrief): HTMLCanvasElement {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const cv = document.createElement("canvas");
  cv.width = STICKER_W * dpr;
  cv.height = STICKER_H * dpr;
  cv.style.aspectRatio = `${STICKER_W} / ${STICKER_H}`;
  const ctx = cv.getContext("2d");
  if (!ctx) return cv;
  ctx.scale(dpr, dpr);

  const rng = mulberry32(seedFromText(brief.text + ":" + brief.emotion));

  // 1. Optional decorations (behind the text)
  drawInkSplatter(ctx, rng, brief.emotion);
  drawLeaves(ctx, rng, brief.emotion);

  // 2. Brush calligraphy of the phrase (centered, fitted to safe area)
  const textBox = drawBrushPhrase(ctx, brief.text);

  // 3. Face on the text — eyes + blush, anchored to the brush text bbox
  drawFace(ctx, textBox, brief.emotion);

  // 4. www flair (joy / hype only)
  drawWWWFlair(ctx, rng, brief.emotion);

  return cv;
}

// ---- Brush phrase ----
interface TextBox {
  x: number;
  y: number;
  w: number;
  h: number;
  fontSize: number;
  lines: string[];
}

function drawBrushPhrase(ctx: CanvasRenderingContext2D, raw: string): TextBox {
  const t = raw.trim();
  const lines = wrapForBrush(t);
  const safeX = SAFE_MARGIN + 6;
  const safeY = SAFE_MARGIN + 12;
  const safeW = STICKER_W - (SAFE_MARGIN + 6) * 2;
  const safeH = STICKER_H - (SAFE_MARGIN + 12) * 2;

  // Find max font size that fits.
  let lo = 28,
    hi = 280,
    best = lo;
  while (lo <= hi) {
    const mid = Math.floor((lo + hi) / 2);
    ctx.font = `${BRUSH_WEIGHT} ${mid}px ${BRUSH_FONT}`;
    const lineH = mid * 1.05;
    let maxW = 0;
    for (const ln of lines) maxW = Math.max(maxW, ctx.measureText(ln).width);
    const totalH = lineH * lines.length;
    if (maxW <= safeW && totalH <= safeH) {
      best = mid;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }

  const size = best;
  ctx.font = `${BRUSH_WEIGHT} ${size}px ${BRUSH_FONT}`;
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const lineH = size * 1.05;
  const totalH = lineH * lines.length;
  const cx = safeX + safeW / 2;
  const startY = safeY + (safeH - totalH) / 2 + lineH / 2;

  // Pure black, no stroke — sumi-e is filled brush.
  ctx.fillStyle = INK;
  for (let i = 0; i < lines.length; i++) {
    ctx.fillText(lines[i], cx, startY + i * lineH);
  }

  // Compute approximate bbox for face placement.
  let maxLineW = 0;
  for (const ln of lines) maxLineW = Math.max(maxLineW, ctx.measureText(ln).width);
  const bx = cx - maxLineW / 2;
  const by = startY - lineH / 2;
  return { x: bx, y: by, w: maxLineW, h: totalH, fontSize: size, lines };
}

function wrapForBrush(text: string): string[] {
  const t = text.trim();
  if (t.length <= 5) return [t];
  if (t.length <= 8) return [t];
  // Split into 2 balanced lines, prefer at punctuation.
  const breakRe = /[\s,、。!?！？]/;
  for (let i = Math.floor(t.length / 2); i > 1; i--) {
    if (breakRe.test(t[i])) return [t.slice(0, i + 1), t.slice(i + 1)];
  }
  const half = Math.ceil(t.length / 2);
  return [t.slice(0, half), t.slice(half)];
}

// ---- Face overlay (eyes + blush) on top of brush text ----
function drawFace(ctx: CanvasRenderingContext2D, box: TextBox, emo: Emotion): void {
  // Face proportions are anchored to the *canvas* — not the bbox width — so the
  // face stays the same readable size whether the phrase is 1 char or 6 chars.
  // This makes the pack look like a coherent series of "iconified text" rather
  // than "tiny eyes drifting apart on long phrases".
  const FACE_W = STICKER_W * 0.32;       // ~118px between eye centers cap
  const eyeSize = Math.min(STICKER_W * 0.07, Math.max(box.fontSize * 0.22, 14));
  const eyeSpacing = Math.min(FACE_W, Math.max(eyeSize * 3.2, box.w * 0.35));
  const cx = box.x + box.w / 2;
  const eyeY = box.y + box.h * 0.34;
  const lx = cx - eyeSpacing / 2;
  const rx = cx + eyeSpacing / 2;

  // Blush first (under eyes so eyes stay top-most and readable).
  const blushR = Math.max(7, eyeSize * 0.95);
  const blushY = eyeY + eyeSize * 1.6;
  drawBlush(ctx, lx - eyeSize * 1.4, blushY, blushR);
  drawBlush(ctx, rx + eyeSize * 1.4, blushY, blushR);

  drawEye(ctx, lx, eyeY, eyeSize, emo, "L");
  drawEye(ctx, rx, eyeY, eyeSize, emo, "R");
}

// All eye styles draw a soft white "pop" disc first so the eye is readable
// when it falls on a black brush stroke.
function eyePop(ctx: CanvasRenderingContext2D, x: number, y: number, r: number): void {
  ctx.save();
  ctx.fillStyle = "#FFFFFF";
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function drawEye(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  s: number,
  emo: Emotion,
  side: "L" | "R",
): void {
  ctx.save();
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  // Eyes are drawn in a soft white "pop" so they're readable against ink strokes.
  // Sumi-e ref shows eyes are *negative space inside* black brush — but for hiragana,
  // a small white-fill + black outline reads more clearly across phrases.
  const fill = "#FFFFFF";
  const ink = INK;
  const lw = Math.max(2.5, s * 0.18);

  // Pop disc behind every eye so it stays readable on black brush ink
  const popR = s * 1.25;
  eyePop(ctx, x, y, popR);

  switch (emo) {
    case "joy": {
      // closed laughing eye "^"-arc, opening downward
      ctx.strokeStyle = ink;
      ctx.lineWidth = lw * 1.3;
      ctx.beginPath();
      ctx.arc(x, y + s * 0.1, s * 0.9, Math.PI * 1.15, Math.PI * 1.85);
      ctx.stroke();
      // tiny lash tick at outer corner
      ctx.beginPath();
      const lashX = side === "L" ? x - s * 0.95 : x + s * 0.95;
      ctx.moveTo(lashX, y - s * 0.15);
      ctx.lineTo(lashX + (side === "L" ? -s * 0.3 : s * 0.3), y - s * 0.45);
      ctx.stroke();
      break;
    }
    case "love": {
      drawHeart(ctx, x, y, s * 1.0, "#E5475A", ink, lw * 0.7);
      break;
    }
    case "surprise": {
      ctx.fillStyle = fill;
      ctx.beginPath();
      ctx.arc(x, y, s, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = ink;
      ctx.lineWidth = lw;
      ctx.stroke();
      ctx.fillStyle = ink;
      ctx.beginPath();
      ctx.arc(x, y, s * 0.42, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
    case "sad": {
      ctx.strokeStyle = ink;
      ctx.lineWidth = lw;
      ctx.beginPath();
      ctx.arc(x, y - s * 0.1, s * 0.9, Math.PI * 0.15, Math.PI * 0.85);
      ctx.stroke();
      break;
    }
    case "question": {
      ctx.fillStyle = ink;
      ctx.font = `${BRUSH_WEIGHT} ${s * 2.2}px ${BRUSH_FONT}`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("?", x, y);
      break;
    }
    case "thanks": {
      ctx.strokeStyle = ink;
      ctx.lineWidth = lw;
      ctx.beginPath();
      ctx.arc(x, y + s * 0.1, s * 0.85, Math.PI * 1.15, Math.PI * 1.85);
      ctx.stroke();
      break;
    }
    case "hype": {
      ctx.strokeStyle = ink;
      ctx.lineWidth = lw * 1.3;
      ctx.lineCap = "round";
      ctx.lineJoin = "round";
      ctx.beginPath();
      if (side === "L") {
        ctx.moveTo(x - s * 0.9, y - s * 0.5);
        ctx.lineTo(x + s * 0.2, y);
        ctx.lineTo(x - s * 0.9, y + s * 0.5);
      } else {
        ctx.moveTo(x + s * 0.9, y - s * 0.5);
        ctx.lineTo(x - s * 0.2, y);
        ctx.lineTo(x + s * 0.9, y + s * 0.5);
      }
      ctx.stroke();
      break;
    }
    case "chill":
    case "neutral":
    default: {
      ctx.fillStyle = ink;
      ctx.beginPath();
      ctx.arc(x, y, s * 0.55, 0, Math.PI * 2);
      ctx.fill();
      break;
    }
  }
  ctx.restore();
}

function drawHeart(
  ctx: CanvasRenderingContext2D,
  cx: number,
  cy: number,
  s: number,
  fill: string,
  stroke: string,
  lw: number,
): void {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.beginPath();
  // Heart from two arcs + bottom V
  ctx.moveTo(0, s * 0.4);
  ctx.bezierCurveTo(s * 0.95, -s * 0.2, s * 0.55, -s * 0.85, 0, -s * 0.25);
  ctx.bezierCurveTo(-s * 0.55, -s * 0.85, -s * 0.95, -s * 0.2, 0, s * 0.4);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
  ctx.strokeStyle = stroke;
  ctx.lineWidth = lw;
  ctx.stroke();
  ctx.restore();
}

function drawBlush(ctx: CanvasRenderingContext2D, x: number, y: number, r: number): void {
  ctx.save();
  ctx.globalAlpha = 0.9;
  ctx.fillStyle = BLUSH;
  ctx.beginPath();
  ctx.ellipse(x, y, r * 1.05, r * 0.7, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

// ---- Decorations ----
function drawInkSplatter(
  ctx: CanvasRenderingContext2D,
  rng: () => number,
  emo: Emotion,
): void {
  const intensity = (() => {
    switch (emo) {
      case "hype":
      case "surprise":
      case "joy":
        return 1.2;
      case "sad":
        return 0.3;
      case "thanks":
      case "love":
        return 0.6;
      default:
        return 0.85;
    }
  })();
  const splats = Math.round(8 + 10 * intensity);
  ctx.save();
  ctx.fillStyle = INK;
  for (let i = 0; i < splats; i++) {
    const x = rng() * STICKER_W;
    const y = rng() * STICKER_H;
    const r = (1 + rng() * 4) * intensity;
    // Avoid covering the dead-center where text lives
    const dx = x - STICKER_W / 2;
    const dy = y - STICKER_H / 2;
    if (dx * dx + dy * dy < 60 * 60) continue;
    ctx.globalAlpha = 0.4 + rng() * 0.4;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
    // Occasional tiny streak
    if (rng() > 0.7) {
      const a = rng() * Math.PI * 2;
      ctx.strokeStyle = INK;
      ctx.lineWidth = r * 0.6;
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(x, y);
      ctx.lineTo(x + Math.cos(a) * r * 4, y + Math.sin(a) * r * 4);
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawLeaves(
  ctx: CanvasRenderingContext2D,
  rng: () => number,
  emo: Emotion,
): void {
  const count = (() => {
    switch (emo) {
      case "joy":
      case "love":
        return 6;
      case "thanks":
      case "hype":
        return 4;
      case "sad":
        return 0;
      case "question":
      case "surprise":
        return 2;
      default:
        return 3;
    }
  })();
  for (let i = 0; i < count; i++) {
    const x = rng() * STICKER_W;
    const y = rng() * STICKER_H;
    // Keep leaves away from text core
    const dx = x - STICKER_W / 2;
    const dy = y - STICKER_H / 2;
    if (dx * dx + dy * dy < 90 * 90) {
      i--;
      continue;
    }
    const size = 8 + rng() * 12;
    const angle = rng() * Math.PI * 2;
    drawLeaf(ctx, x, y, size, angle, rng() > 0.5 ? LEAF_A : LEAF_B);
  }
}

function drawLeaf(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  s: number,
  angle: number,
  color: string,
): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);
  ctx.fillStyle = color;
  ctx.beginPath();
  ctx.moveTo(0, -s);
  ctx.bezierCurveTo(s * 0.7, -s * 0.5, s * 0.7, s * 0.5, 0, s);
  ctx.bezierCurveTo(-s * 0.7, s * 0.5, -s * 0.7, -s * 0.5, 0, -s);
  ctx.closePath();
  ctx.fill();
  // central vein
  ctx.strokeStyle = "rgba(0,0,0,0.18)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, -s * 0.95);
  ctx.lineTo(0, s * 0.95);
  ctx.stroke();
  ctx.restore();
}

function drawWWWFlair(
  ctx: CanvasRenderingContext2D,
  rng: () => number,
  emo: Emotion,
): void {
  if (emo !== "joy" && emo !== "hype" && emo !== "surprise") return;
  ctx.save();
  ctx.fillStyle = W_TEXT;
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
  const positions: { x: number; y: number; size: number; rot: number }[] = [
    { x: 16, y: STICKER_H * 0.45, size: 22, rot: -0.18 },
    { x: STICKER_W - 86, y: STICKER_H * 0.4, size: 24, rot: 0.12 },
    { x: 32, y: STICKER_H - 22, size: 20, rot: -0.05 },
  ];
  for (const p of positions) {
    if (rng() < 0.25) continue;
    ctx.save();
    ctx.translate(p.x, p.y);
    ctx.rotate(p.rot);
    ctx.font = `700 ${p.size}px ${W_FONT}`;
    ctx.fillText("www", 0, 0);
    ctx.restore();
  }
  ctx.restore();
}

export async function canvasToBlob(cv: HTMLCanvasElement): Promise<Blob> {
  return new Promise((resolve, reject) => {
    cv.toBlob(
      (b) => (b ? resolve(b) : reject(new Error("canvas.toBlob returned null"))),
      "image/png",
    );
  });
}
