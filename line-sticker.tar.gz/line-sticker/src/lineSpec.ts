// LINE Creators Market 公式仕様 (2026 時点で安定している基本形)
// https://creator.line.me/ja/guideline/sticker/

export const STICKER_W = 370;
export const STICKER_H = 320;
export const MAIN_W = 240;
export const MAIN_H = 240;
export const TAB_W = 96;
export const TAB_H = 74;

// 余白は端から 10px 以上
export const SAFE_MARGIN = 10;

// セット枚数の選択肢
export const STICKER_COUNTS = [8, 16, 24, 32, 40] as const;
export type StickerCount = (typeof STICKER_COUNTS)[number];

export function pickStickerCount(n: number): StickerCount {
  // 最も近い小さい/同じ規定枚数に丸める
  for (let i = STICKER_COUNTS.length - 1; i >= 0; i--) {
    if (n >= STICKER_COUNTS[i]) return STICKER_COUNTS[i];
  }
  return STICKER_COUNTS[0];
}

// 提出時のファイル名規約: 01.png 〜 NN.png + main.png + tab.png
export function stickerFilename(index1Based: number): string {
  return `${String(index1Based).padStart(2, "0")}.png`;
}
