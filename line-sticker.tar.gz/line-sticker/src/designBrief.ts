import type { Emotion, PhraseCandidate } from "./analyzer";
import { STICKER_W, STICKER_H, SAFE_MARGIN } from "./lineSpec";

// Per-emotion design language — locked to the sumi-e brush + face-on-text concept.
// All sticker bodies are pure ink (#0E0E10). Color comes from accents (blush/leaves)
// and emotion-specific small marks. This keeps the 40-pack visually coherent.
export interface Palette {
  bg: "transparent";
  fill: string;     // ink color (always near-black for sumi-e consistency)
  stroke: string;   // unused for fill-only sumi-e, kept for compatibility
  accent: string;   // emotion accent color (heart / leaf-tone / question / etc.)
  mood: string;     // adjective list for downstream image-gen prompts
  eyeMark: string;  // textual descriptor for the eye style on this emotion
}

const INK = "#0E0E10";

export const PALETTES: Record<Emotion, Palette> = {
  joy:      { bg: "transparent", fill: INK, stroke: INK, accent: "#7BB661", mood: "playful, laughing, leafy",   eyeMark: "closed laughing eyes (>‿<)" },
  love:     { bg: "transparent", fill: INK, stroke: INK, accent: "#E5475A", mood: "warm, affectionate, soft",    eyeMark: "heart eyes (♥ ♥)" },
  surprise: { bg: "transparent", fill: INK, stroke: INK, accent: "#FFE066", mood: "shocked, popping, high-contrast", eyeMark: "wide round eyes (o O)" },
  sad:      { bg: "transparent", fill: INK, stroke: INK, accent: "#7CC2FF", mood: "melancholic, gentle, droopy", eyeMark: "droopy downward arcs" },
  question: { bg: "transparent", fill: INK, stroke: INK, accent: "#9C5BFF", mood: "curious, tilted",             eyeMark: "question-mark eyes (?)" },
  chill:    { bg: "transparent", fill: INK, stroke: INK, accent: "#5DD6B9", mood: "calm, casual",                eyeMark: "simple dot eyes" },
  hype:     { bg: "transparent", fill: INK, stroke: INK, accent: "#FF4F2E", mood: "energetic, bold, motion-lined", eyeMark: "determined angled eyes (>< ><)" },
  thanks:   { bg: "transparent", fill: INK, stroke: INK, accent: "#FFB347", mood: "grateful, warm, slight bow",  eyeMark: "gentle closed arcs (‿ ‿)" },
  neutral:  { bg: "transparent", fill: INK, stroke: INK, accent: "#06C755", mood: "clean, simple, friendly",     eyeMark: "simple dot eyes" },
};

export interface StickerBrief {
  index: number;
  text: string;
  emotion: Emotion;
  palette: Palette;
  /** Prompt for image-generation AI handoff (DALL-E / Midjourney / SDXL etc.) */
  imagePrompt: string;
  /** Negative prompt suggestions */
  negativePrompt: string;
  /** Concrete visual direction notes */
  notes: string[];
}

const CHARACTER_HINT_DEFAULT =
  "the brush text itself is the character — eyes and blush integrated into the strokes, no separate mascot body, the calligraphy *is* the face";

export interface BriefOptions {
  /** Optional: a single mascot/character description to keep the pack coherent. */
  characterHint?: string;
  /** Pack title hint (e.g., "kawaii daily reactions"). */
  packTheme?: string;
}

export function buildBrief(
  candidates: PhraseCandidate[],
  opts: BriefOptions = {},
): StickerBrief[] {
  const charHint = opts.characterHint?.trim() || CHARACTER_HINT_DEFAULT;
  const theme = opts.packTheme?.trim() || "daily-use Japanese reactions";

  return candidates.map((c, i): StickerBrief => {
    const palette = PALETTES[c.emotion];
    const imagePrompt = [
      `LINE sticker, sumi-e Japanese brush calligraphy, transparent background PNG, ${STICKER_W}x${STICKER_H}px,`,
      `${theme}, ${palette.mood}.`,
      `The Japanese phrase "${c.text}" is rendered as bold black ink brush strokes (Yuji-Boku style)`,
      `with two cute ${palette.eyeMark} embedded into the upper portion of the strokes,`,
      `pink blush ovals (#F4A6A6) on the cheeks just below the eyes,`,
      `accent color ${palette.accent},`,
      "scattered green matcha leaves around (more for joy/love, none for sad),",
      "ink splatter dots and short streaks for energy,",
      "pure white or transparent background, no scene, no panels, no extra text,",
      "high contrast pure black ink on white, hand-drawn sumi-e feel, generous 10px safe margin.",
      `Style anchor: ${charHint}.`,
    ].join(" ");
    const negativePrompt =
      "photorealistic, gradient backgrounds, color text fill, 3D render, vector flat illustration, anime character body, watermark, signature, cropped letters, English captions, busy detail, framing border";
    const notes: string[] = [
      `Emotion: ${c.emotion}`,
      `Eyes: ${palette.eyeMark}`,
      `Source signal: ${c.source} (×${c.count})`,
      `Safe area: keep all art ≥ ${SAFE_MARGIN}px from edge.`,
      `Sticker filename target: ${String(i + 1).padStart(2, "0")}.png`,
    ];
    return {
      index: i + 1,
      text: c.text,
      emotion: c.emotion,
      palette,
      imagePrompt,
      negativePrompt,
      notes,
    };
  });
}

export function briefsToMarkdown(briefs: StickerBrief[]): string {
  const head = [
    "# LINE Sticker Pack Brief",
    "",
    "_Auto-generated from chat history. Brush up via your preferred image-gen AI._",
    "",
    "## Pack-wide direction",
    "- Dimensions: 370×320px max, transparent PNG.",
    "- Margin: ≥ 10px from edges.",
    "- Style: consistent mascot/line-art across all stickers; only color & expression change with emotion.",
    "",
    "## Stickers",
    "",
  ].join("\n");
  const body = briefs
    .map((b) =>
      [
        `### ${String(b.index).padStart(2, "0")}. 「${b.text}」`,
        ``,
        `- Emotion: **${b.emotion}**`,
        `- Palette: fill \`${b.palette.fill}\` / stroke \`${b.palette.stroke}\` / accent \`${b.palette.accent}\``,
        `- Mood: ${b.palette.mood}`,
        ``,
        `**Image prompt**`,
        ``,
        "```",
        b.imagePrompt,
        "```",
        ``,
        `**Negative prompt**`,
        ``,
        "```",
        b.negativePrompt,
        "```",
        ``,
      ].join("\n"),
    )
    .join("\n");
  return head + body;
}

export function briefsToPromptJson(briefs: StickerBrief[]): string {
  const payload = briefs.map((b) => ({
    index: b.index,
    filename: `${String(b.index).padStart(2, "0")}.png`,
    text: b.text,
    emotion: b.emotion,
    palette: b.palette,
    prompt: b.imagePrompt,
    negative_prompt: b.negativePrompt,
    width: STICKER_W,
    height: STICKER_H,
  }));
  return JSON.stringify({ stickers: payload }, null, 2);
}
