import "@fontsource/yuji-boku/400.css";
import "@fontsource/yuji-mai/400.css";
import "./style.css";
import JSZip from "jszip";
import { listSpeakers, parseChat, type Message } from "./parser";
import { analyze, type AnalysisResult, type PhraseCandidate } from "./analyzer";
import {
  buildBrief,
  briefsToMarkdown,
  briefsToPromptJson,
  type StickerBrief,
} from "./designBrief";
import { canvasToBlob, ensureFonts, preloadGlyphs, renderSticker } from "./canvasRender";
import type { Emotion } from "./analyzer";
import { stickerFilename } from "./lineSpec";

const $ = <T extends HTMLElement = HTMLElement>(id: string) => {
  const el = document.getElementById(id);
  if (!el) throw new Error(`#${id} not found`);
  return el as T;
};

interface State {
  messages: Message[];
  speakers: { name: string; count: number }[];
  result: AnalysisResult | null;
  briefs: StickerBrief[];
}

const state: State = {
  messages: [],
  speakers: [],
  result: null,
  briefs: [],
};

function setupDropzone() {
  const dz = $("dropzone");
  const fileInput = $<HTMLInputElement>("file-input");
  const pick = $("pick-file");
  const sample = $("load-sample");

  pick.addEventListener("click", () => fileInput.click());
  fileInput.addEventListener("change", () => {
    if (fileInput.files) handleFiles(Array.from(fileInput.files));
  });

  ["dragenter", "dragover"].forEach((ev) =>
    dz.addEventListener(ev, (e) => {
      e.preventDefault();
      dz.classList.add("drag");
    }),
  );
  ["dragleave", "drop"].forEach((ev) =>
    dz.addEventListener(ev, (e) => {
      e.preventDefault();
      dz.classList.remove("drag");
    }),
  );
  dz.addEventListener("drop", (e) => {
    const dt = (e as DragEvent).dataTransfer;
    if (!dt) return;
    const files = Array.from(dt.files).filter(
      (f) => f.type === "text/plain" || f.name.endsWith(".txt"),
    );
    if (files.length) handleFiles(files);
  });

  sample.addEventListener("click", async () => {
    const res = await fetch("./samples/sample-chat.txt");
    if (!res.ok) {
      alert("サンプルが見つかりません");
      return;
    }
    const text = await res.text();
    ingestText([text]);
  });
}

async function handleFiles(files: File[]) {
  const texts: string[] = [];
  for (const f of files) texts.push(await f.text());
  ingestText(texts);
}

function ingestText(texts: string[]) {
  const all: Message[] = [];
  for (const t of texts) all.push(...parseChat(t));
  state.messages = all;
  state.speakers = listSpeakers(all);
  if (!all.length) {
    alert("メッセージを抽出できませんでした。LINEのテキスト形式エクスポートか確認してください。");
    return;
  }
  populateSpeakerFilter();
  $("controls").hidden = false;
}

function populateSpeakerFilter() {
  const sel = $<HTMLSelectElement>("speaker-filter");
  sel.innerHTML = "";
  const optAll = document.createElement("option");
  optAll.value = "";
  optAll.textContent = `(全員 — ${state.messages.length} 件)`;
  sel.appendChild(optAll);
  for (const s of state.speakers) {
    const o = document.createElement("option");
    o.value = s.name;
    o.textContent = `${s.name} — ${s.count} 件`;
    sel.appendChild(o);
  }
  // Default: most-talkative speaker is usually "self" (heuristic — user can change)
  if (state.speakers[0]) sel.value = state.speakers[0].name;
}

function setupAnalyze() {
  $("analyze").addEventListener("click", runAnalyze);
}

function runAnalyze() {
  const speaker = $<HTMLSelectElement>("speaker-filter").value || undefined;
  const maxIdeas = Number($<HTMLInputElement>("max-ideas").value) || 40;
  const minFreq = Number($<HTMLInputElement>("min-freq").value) || 3;
  const result = analyze(state.messages, { speakerFilter: speaker, minFreq, maxIdeas });
  state.result = result;
  state.briefs = buildBrief(result.candidates);
  renderResults();
  renderMockups();
}

function renderResults() {
  const r = state.result;
  if (!r) return;
  $("step-results").hidden = false;
  const meta = `分析対象 ${r.speakerMessages} 件 / 全 ${r.totalMessages} 件 → ${r.candidates.length} 候補`;
  $("result-meta").textContent = meta;
  const ideasEl = $("ideas");
  ideasEl.innerHTML = "";
  for (const c of r.candidates) ideasEl.appendChild(renderIdeaCard(c));
}

function renderIdeaCard(c: PhraseCandidate): HTMLElement {
  const card = document.createElement("div");
  card.className = "idea-card";
  card.innerHTML = `
    <div class="text"></div>
    <div class="meta">
      <span class="tag"></span>
      <span class="count"></span>
      <span class="src"></span>
    </div>
    <div class="ctx"></div>
  `;
  (card.querySelector(".text") as HTMLElement).textContent = c.text;
  (card.querySelector(".tag") as HTMLElement).textContent = c.emotion;
  (card.querySelector(".count") as HTMLElement).textContent = `×${c.count}`;
  (card.querySelector(".src") as HTMLElement).textContent = c.source;
  const ctx = card.querySelector(".ctx") as HTMLElement;
  if (c.contexts.length) ctx.textContent = c.contexts.join("\n");
  else ctx.remove();
  return card;
}

async function renderMockups() {
  $("step-mockups").hidden = false;
  const allText = state.briefs.map((b) => b.text).join("");
  await ensureFonts(allText);
  await preloadGlyphs(allText);
  const wrap = $("mockups");
  wrap.innerHTML = "";
  for (const b of state.briefs) {
    const cv = renderSticker(b);
    const cell = document.createElement("div");
    cell.className = "mockup";
    cell.appendChild(cv);
    const lab = document.createElement("div");
    lab.className = "label";
    lab.textContent = `${String(b.index).padStart(2, "0")} ${b.text}`;
    cell.appendChild(lab);
    wrap.appendChild(cell);
  }
}

function setupExports() {
  $("export-pngs").addEventListener("click", exportZip);
  $("export-brief").addEventListener("click", () => {
    const md = briefsToMarkdown(state.briefs);
    void copyToClipboard(md, "デザインブリーフを Markdown でコピーしました");
  });
  $("export-prompts").addEventListener("click", () => {
    const json = briefsToPromptJson(state.briefs);
    void copyToClipboard(json, "画像生成 AI 用プロンプト JSON をコピーしました");
  });
}

async function exportZip() {
  if (!state.briefs.length) return;
  const zip = new JSZip();
  for (const b of state.briefs) {
    const cv = renderSticker(b);
    const blob = await canvasToBlob(cv);
    zip.file(stickerFilename(b.index), blob);
  }
  zip.file("brief.md", briefsToMarkdown(state.briefs));
  zip.file("prompts.json", briefsToPromptJson(state.briefs));
  const out = await zip.generateAsync({ type: "blob" });
  triggerDownload(out, "line-sticker-pack.zip");
}

function triggerDownload(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}

async function copyToClipboard(text: string, msg: string) {
  try {
    await navigator.clipboard.writeText(text);
    flash(msg);
  } catch {
    flash("コピー失敗。ブラウザのクリップボード許可を確認してください。");
  }
}

function flash(msg: string) {
  const el = document.createElement("div");
  el.textContent = msg;
  el.style.cssText =
    "position:fixed;left:50%;bottom:24px;transform:translateX(-50%);background:#06c755;color:#08210f;padding:10px 16px;border-radius:8px;font-weight:700;z-index:99;box-shadow:0 6px 24px rgba(0,0,0,.4)";
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1800);
}

async function previewRender() {
  const text = ($<HTMLInputElement>("preview-text").value || "草").trim();
  const emotion = $<HTMLSelectElement>("preview-emotion").value as Emotion;
  await ensureFonts(text);
  await preloadGlyphs(text);
  const fakeBrief = {
    index: 1,
    text,
    emotion,
    palette: {
      bg: "transparent" as const,
      fill: "#0E0E10",
      stroke: "#0E0E10",
      accent: "#7BB661",
      mood: "preview",
      eyeMark: "preview eyes",
    },
    imagePrompt: "",
    negativePrompt: "",
    notes: [],
  };
  const cv = renderSticker(fakeBrief);
  const stage = $("preview-stage");
  stage.innerHTML = "";
  stage.appendChild(cv);
}

function setupPreview() {
  $("preview-render").addEventListener("click", () => void previewRender());
  $("preview-download").addEventListener("click", async () => {
    const cv = $("preview-stage").querySelector("canvas") as HTMLCanvasElement | null;
    if (!cv) {
      await previewRender();
      return;
    }
    const blob = await canvasToBlob(cv);
    const text = ($<HTMLInputElement>("preview-text").value || "草").trim();
    triggerDownload(blob, `preview-${text}.png`);
  });
  // Auto-render on load so user immediately sees the concept art reproduction
  void previewRender();
}

setupDropzone();
setupAnalyze();
setupExports();
setupPreview();
