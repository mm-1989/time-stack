import type { Message } from "./parser";

// Sticker-text mining strategy
// ---------------------------------
// LINE スタンプは 1 〜 12 文字程度の短い反応・感情表現が中心。
// よって以下のシグナルを組み合わせる:
//
// 1. 短文丸ごとの出現頻度 (whole-message frequency)
//    "おつかれ" "わかる" "了解" のような単発返信はそのまま候補。
// 2. 文字 n-gram (2〜6) の頻度
//    形態素解析を入れずとも、共起する短いフレーズを拾える。
// 3. 絵文字 / 顔文字 の出現
// 4. 末尾感嘆 (!! ?? www 〜 等) のシグナル付与
//
// 各候補に対して
//   - score: 出現頻度 (短文ボーナス込み)
//   - emotion: 感情分類 (joy / love / surprise / sad / question / chill / hype / thanks)
//   - contexts: 周辺メッセージ 2〜3 件
// を付与して返す。

export type Emotion =
  | "joy"
  | "love"
  | "surprise"
  | "sad"
  | "question"
  | "chill"
  | "hype"
  | "thanks"
  | "neutral";

export interface PhraseCandidate {
  text: string;
  count: number;
  score: number;
  emotion: Emotion;
  source: "whole" | "ngram" | "emoji";
  contexts: string[]; // up to 3 example surrounding messages
}

const EMOTION_LEXICON: { re: RegExp; emo: Emotion }[] = [
  { re: /(ありがと|あざ|サンキュ|thx|thanks|多謝)/i, emo: "thanks" },
  { re: /(好き|大好き|愛|ハート|love|だいすき|すこ|かわい)/i, emo: "love" },
  { re: /(やば|まじ|マジ|うそ|ウソ|嘘|えっ|ええっ|びっく)/, emo: "surprise" },
  { re: /(\?|？|なに|何|どこ|いつ|だれ|誰|どう)/, emo: "question" },
  { re: /(かなし|寂し|つら|ぴえん|泣|涙|sad)/i, emo: "sad" },
  // chill: 挨拶・相槌・了承・共感
  {
    re: /(おはよ|おやすみ|おつ|お疲|了解|りょ|おk|ok|はい|うん|いいよ|わかる|ねー|そだね|だね|いってら|いってき|おけ)/i,
    emo: "chill",
  },
  { re: /(www|w$|笑|草|wktk|興奮|テンション|最高|やった|うれし|嬉し|happy|嬉|たのし|楽し)/i, emo: "joy" },
  { re: /(行こ|やろ|頑張|がんばろ|ファイト|fight|いっせーの|ガチ|本気|燃え|花金)/i, emo: "hype" },
];

function classifyEmotion(text: string): Emotion {
  for (const { re, emo } of EMOTION_LEXICON) if (re.test(text)) return emo;
  return "neutral";
}

// Strip trailing repeats like "wwww" -> "w" cluster, but keep length info.
function normalize(text: string): string {
  return text
    .replace(/[ \t]+/g, " ")
    .replace(/(.)\1{3,}/g, "$1$1$1") // collapse 4+ repeats of same char to 3
    .trim();
}

const STOPWORD_NGRAMS = new Set<string>([
  // particles / common JP filler that pollute n-gram top
  "です", "ます", "した", "して", "ない", "なる", "ある", "いる",
  "から", "けど", "って", "とか", "けれ", "なん", "もの", "こと",
  "んだ", "んで", "んが", "んか", "ねえ", "ねー", "そう", "うん",
  // English/space-bigrams
  "  ", " a", "a ",
]);

function isLikelyMeaningful(s: string): boolean {
  if (s.length < 2) return false;
  if (/^[\s.,!?！？]+$/.test(s)) return false;
  if (STOPWORD_NGRAMS.has(s)) return false;
  return true;
}

// Extract emoji + popular kaomoji parts. Prefer Unicode prop classes when available.
const EMOJI_RE = /[\p{Extended_Pictographic}\u{1F000}-\u{1FAFF}]/gu;

function countEmojis(text: string): Map<string, number> {
  const counts = new Map<string, number>();
  const matches = text.match(EMOJI_RE);
  if (!matches) return counts;
  for (const e of matches) counts.set(e, (counts.get(e) ?? 0) + 1);
  return counts;
}

function ngrams(text: string, n: number): string[] {
  const out: string[] = [];
  if (text.length < n) return out;
  // Skip spaces at boundary to prefer meaningful segments.
  for (let i = 0; i <= text.length - n; i++) {
    const s = text.slice(i, i + n);
    if (s.includes("\n")) continue;
    out.push(s);
  }
  return out;
}

export interface AnalyzeOptions {
  speakerFilter?: string; // restrict to messages from this speaker
  minFreq: number;
  maxIdeas: number;
}

export interface AnalysisResult {
  totalMessages: number;
  speakerMessages: number;
  candidates: PhraseCandidate[];
}

export function analyze(messages: Message[], opts: AnalyzeOptions): AnalysisResult {
  const filtered = opts.speakerFilter
    ? messages.filter((m) => m.speaker === opts.speakerFilter)
    : messages;

  // 1. Whole-message frequency for short messages (<= 14 chars)
  const wholeCounts = new Map<string, number>();
  const wholeContexts = new Map<string, string[]>();
  for (let i = 0; i < filtered.length; i++) {
    const m = filtered[i];
    const text = normalize(m.text);
    if (!text || text.length > 14 || text.includes("\n")) continue;
    if (!/[ぁ-んァ-ヶ一-龯a-zA-Z0-9?!？！]/.test(text)) continue; // must contain a non-symbol char
    wholeCounts.set(text, (wholeCounts.get(text) ?? 0) + 1);
    if (!wholeContexts.has(text)) {
      const ctx: string[] = [];
      for (let j = Math.max(0, i - 1); j <= Math.min(filtered.length - 1, i + 1); j++) {
        ctx.push(`${filtered[j].speaker}: ${filtered[j].text.replace(/\n/g, " ")}`);
      }
      wholeContexts.set(text, ctx);
    }
  }

  // 2. Character n-grams (2..6) over all messages
  const ngramCounts = new Map<string, number>();
  for (const m of filtered) {
    const t = normalize(m.text);
    if (!t) continue;
    for (let n = 2; n <= 6; n++) {
      for (const g of ngrams(t, n)) {
        if (!isLikelyMeaningful(g)) continue;
        ngramCounts.set(g, (ngramCounts.get(g) ?? 0) + 1);
      }
    }
  }

  // 3. Emoji counts (often used as one-shot stickers concept)
  const emojiCounts = new Map<string, number>();
  for (const m of filtered) {
    const ec = countEmojis(m.text);
    for (const [e, c] of ec) emojiCounts.set(e, (emojiCounts.get(e) ?? 0) + c);
  }

  // Build candidate list, preferring whole > ngram > emoji.
  const cands = new Map<string, PhraseCandidate>();

  for (const [text, count] of wholeCounts) {
    if (count < opts.minFreq) continue;
    // Whole-message bonus: short messages used as standalone reactions are gold.
    const lenBonus = text.length <= 6 ? 1.6 : text.length <= 10 ? 1.3 : 1.1;
    const score = count * lenBonus + 5; // baseline boost vs ngrams
    cands.set(text, {
      text,
      count,
      score,
      emotion: classifyEmotion(text),
      source: "whole",
      contexts: wholeContexts.get(text) ?? [],
    });
  }

  // Suppress n-grams that are substrings of an already chosen whole-message phrase
  const chosenWholes = Array.from(cands.values()).filter((c) => c.source === "whole");
  const ngramRanked = Array.from(ngramCounts.entries())
    .filter(([s, c]) => c >= opts.minFreq && !STOPWORD_NGRAMS.has(s))
    .sort((a, b) => b[1] - a[1]);

  for (const [s, count] of ngramRanked) {
    if (cands.has(s)) continue;
    if (chosenWholes.some((w) => w.text.includes(s) && w.count * 1.5 >= count)) continue;
    // Penalize bigrams unless very frequent
    const lenAdj = s.length === 2 ? 0.7 : s.length === 3 ? 1.0 : 1.15;
    const score = count * lenAdj;
    cands.set(s, {
      text: s,
      count,
      score,
      emotion: classifyEmotion(s),
      source: "ngram",
      contexts: [],
    });
  }

  for (const [e, count] of emojiCounts) {
    if (count < opts.minFreq) continue;
    if (cands.has(e)) continue;
    cands.set(e, {
      text: e,
      count,
      score: count * 0.9,
      emotion: classifyEmotion(e),
      source: "emoji",
      contexts: [],
    });
  }

  // De-duplicate near-duplicates: keep longer/higher-score variant.
  const all = Array.from(cands.values()).sort((a, b) => b.score - a.score);
  const kept: PhraseCandidate[] = [];
  for (const c of all) {
    const dup = kept.find(
      (k) =>
        (k.text.includes(c.text) && k.text.length <= c.text.length + 2) ||
        (c.text.includes(k.text) && c.text.length <= k.text.length + 2),
    );
    if (dup) continue;
    kept.push(c);
    if (kept.length >= opts.maxIdeas) break;
  }

  return {
    totalMessages: messages.length,
    speakerMessages: filtered.length,
    candidates: kept,
  };
}
