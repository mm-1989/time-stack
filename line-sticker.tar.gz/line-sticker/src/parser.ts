// LINE chat history (.txt export) parser.
// Supports both JA and EN export formats, both old (date header) and new (per-line date) layouts.
//
// JA example:
//   [LINE] 〇〇とのトーク履歴
//   保存日時：2025/04/01 12:34
//
//   2025/04/01(火)
//   12:01\tたろう\tおはよ
//   12:03\tはなこ\tおはー!
//   [写真]
//
// EN example:
//   [LINE] Chat history with 〇〇
//   Saved on: 2025/04/01 12:34
//
//   Tue, 04/01/2025
//   12:01\tTaro\tGood morning
//
// Notes:
// - Time at start of line: HH:MM (24h) — used as message anchor.
// - Continuation lines (multi-line messages) have no leading time and are appended.
// - System markers like "[写真]" "[スタンプ]" "[ファイル]" "通話時間 00:23" are filtered out.

export interface Message {
  /** ISO date string (YYYY-MM-DD) when known, else "". */
  date: string;
  /** "HH:MM" 24h. */
  time: string;
  speaker: string;
  text: string;
}

const SYSTEM_PATTERNS: RegExp[] = [
  /^\[(写真|スタンプ|動画|ファイル|ボイスメッセージ|位置情報|連絡先|アルバム|ノート|不在着信)\]$/,
  /^\[(Photo|Sticker|Video|File|Voice message|Location|Contact|Album|Note|Missed call)\]$/i,
  /^☎\s/, // call notifications
  /^通話時間/,
  /^Call time/i,
  /メッセージの送信を取り消しました/,
  /unsent a message/i,
  /がグループに参加しました$/,
  /がグループから退出しました$/,
];

function isSystemMessage(t: string): boolean {
  if (!t) return true;
  return SYSTEM_PATTERNS.some((re) => re.test(t.trim()));
}

// Date header: "2025/04/01(火)" or "2025/04/01" or "Tue, 04/01/2025" or "04/01/2025"
const DATE_LINE_JP = /^(\d{4})[\/\-](\d{1,2})[\/\-](\d{1,2})(?:\([^)]+\))?\s*$/;
const DATE_LINE_EN_SLASH = /^(?:\w+,\s*)?(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})\s*$/;

function tryParseDateHeader(line: string): string | null {
  const trimmed = line.trim();
  let m = DATE_LINE_JP.exec(trimmed);
  if (m) {
    const [, y, mo, d] = m;
    return `${y}-${mo.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }
  m = DATE_LINE_EN_SLASH.exec(trimmed);
  if (m) {
    const [, mo, d, y] = m;
    return `${y}-${mo.padStart(2, "0")}-${d.padStart(2, "0")}`;
  }
  return null;
}

// Message line: "HH:MM\tspeaker\tbody"  (tabs are canonical, but spaces also seen)
const MSG_LINE = /^(\d{1,2}:\d{2})[\t ]+([^\t]+?)[\t ]+(.*)$/;

export function parseChat(raw: string): Message[] {
  const lines = raw.replace(/\r\n?/g, "\n").split("\n");
  const out: Message[] = [];
  let currentDate = "";
  let last: Message | null = null;

  for (const line of lines) {
    if (line === "") {
      last = null;
      continue;
    }
    const dt = tryParseDateHeader(line);
    if (dt) {
      currentDate = dt;
      last = null;
      continue;
    }
    const m = MSG_LINE.exec(line);
    if (m) {
      const [, time, speaker, body] = m;
      const text = body.trim();
      if (isSystemMessage(text)) {
        last = null;
        continue;
      }
      const msg: Message = { date: currentDate, time, speaker: speaker.trim(), text };
      out.push(msg);
      last = msg;
    } else if (last) {
      // Continuation of previous message (multi-line body).
      const cont = line.trimEnd();
      if (cont) last.text += "\n" + cont;
    }
  }
  return out;
}

export function listSpeakers(msgs: Message[]): { name: string; count: number }[] {
  const map = new Map<string, number>();
  for (const m of msgs) map.set(m.speaker, (map.get(m.speaker) ?? 0) + 1);
  return Array.from(map, ([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count);
}
